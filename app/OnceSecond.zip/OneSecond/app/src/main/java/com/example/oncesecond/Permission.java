package com.example.oncesecond;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Permission extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);
    }
}